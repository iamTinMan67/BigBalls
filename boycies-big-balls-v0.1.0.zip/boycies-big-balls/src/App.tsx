import { useEffect, useMemo, useState } from 'react'
import { Activity, Award, Banknote, Camera, CircleHelp, ClipboardList, Clock3, Crown, Gamepad2, History, House, MonitorPlay, Pause, Play, RotateCcw, Save, Settings, ShieldAlert, Target, Trophy, Users, Wallet, Wifi, X } from 'lucide-react'

type Player = { name: string; score: number; bank: number; bucks: number; balls: number; missUsed: boolean }
type Event = { at: string; text: string; kind: string }
type Question = { text: string; answer: string; type: string; steal: boolean; options?: string[] }
const questions: Question[] = [
  { text: 'Which river runs through the city of London?', answer: 'The Thames', type: 'General knowledge', steal: true, options: ['The Severn', 'The Thames', 'The Trent', 'The Mersey'] },
  { text: 'How many sides does a dodecagon have?', answer: '12', type: 'Quick thinking', steal: true },
  { text: 'What is the approximate weight of a UK one-pound coin in grams?', answer: '8.75g', type: 'Estimation', steal: false },
  { text: 'Which came first: the television or the traffic light?', answer: 'Traffic light', type: 'Higher or lower / order', steal: false },
  { text: 'In which decade did the first episode of Only Fools and Horses air?', answer: '1980s', type: 'Entertainment', steal: true, options: ['1960s', '1970s', '1980s', '1990s'] },
  { text: 'True or false: a group of goldfish is called a troubling.', answer: 'False', type: 'True / false', steal: true, options: ['True', 'False'] },
  { text: 'What is the name for a word that reads the same backwards?', answer: 'Palindrome', type: 'Riddle', steal: true },
]
const initialPlayers: Player[] = [
  { name: 'Player One', score: 0, bank: 0, bucks: 100, balls: 4, missUsed: false },
  { name: 'Player Two', score: 0, bank: 0, bucks: 100, balls: 4, missUsed: false },
]
const rounds = ['Quick-fire: Build Your Arsenal', 'Grab My Balls', 'The Big Balls Showdown']
const fmt = (n: number) => `${Math.max(0, n)}s`

export default function App() {
  const [players, setPlayers] = useState<Player[]>(() => {
    try { const v = localStorage.getItem('bbb_players'); return v ? JSON.parse(v) : initialPlayers } catch { return initialPlayers }
  })
  const [round, setRound] = useState(0)
  const [active, setActive] = useState(0)
  const [tab, setTab] = useState('control')
  const [status, setStatus] = useState('Ready to play')
  const [paused, setPaused] = useState(false)
  const [questionIndex, setQuestionIndex] = useState(0)
  const [answer, setAnswer] = useState('')
  const [reveal, setReveal] = useState(false)
  const [stealMode, setStealMode] = useState(false)
  const [events, setEvents] = useState<Event[]>([{ at: new Date().toLocaleTimeString(), text: 'Game room created. The balls are ready.', kind: 'system' }])
  const [shot, setShot] = useState('Choose a shot outcome')
  const [showSettings, setShowSettings] = useState(false)
  const [relationship, setRelationship] = useState('Friends')
  const [gameTitle, setGameTitle] = useState("Boycie's Big Balls")
  const [finalBlack, setFinalBlack] = useState(false)
  const [winner, setWinner] = useState('')
  const q = questions[questionIndex % questions.length]
  const current = players[active]
  const addEvent = (text: string, kind = 'system') => setEvents(e => [{ at: new Date().toLocaleTimeString(), text, kind }, ...e].slice(0, 80))
  useEffect(() => { localStorage.setItem('bbb_players', JSON.stringify(players)) }, [players])
  const updatePlayer = (i: number, patch: Partial<Player>) => setPlayers(p => p.map((x, n) => n === i ? { ...x, ...patch } : x))
  const reset = () => {
    setPlayers(initialPlayers); setRound(0); setActive(0); setQuestionIndex(0); setAnswer(''); setReveal(false); setStealMode(false); setWinner(''); setFinalBlack(false); setPaused(false); setStatus('Ready to play'); setEvents([{ at: new Date().toLocaleTimeString(), text: 'New game started.', kind: 'system' }]); addEvent('New game started.')
  }
  const recordShot = (outcome: 'POT'|'MISS'|'FOUL') => {
    const p = current
    if (outcome === 'POT') {
      updatePlayer(active, { score: p.score + 10, bank: p.bank + 10, bucks: p.bucks + 50, balls: Math.max(0, p.balls - (round === 2 ? 1 : 0)) })
      setShot(`${p.name} pots a ball! +10 Bank Time · +50 BB$`)
      addEvent(`${p.name}: POT — +10 Bank Time and +50 BB$.`, 'good')
    } else if (outcome === 'MISS') {
      updatePlayer(active, { missUsed: true })
      setShot(`${p.name} misses. No reward this time.`); addEvent(`${p.name}: MISS recorded.`, 'warn')
    } else {
      updatePlayer(active, { score: Math.max(0, p.score - 5), bank: Math.max(0, p.bank - 5) })
      setShot(`${p.name} foul recorded. Provisional -5 Bank Time.`); addEvent(`${p.name}: FOUL — provisional -5 Bank Time.`, 'bad')
    }
  }
  const answerQuestion = (correct: boolean) => {
    if (correct) {
      updatePlayer(active, { bank: current.bank + 5, bucks: current.bucks + 25, score: current.score + 5 })
      addEvent(`${current.name} answered correctly: +5 Bank Time and +25 BB$.`, 'good')
      setStatus('Correct answer!')
    } else {
      addEvent(`${current.name} gave an incorrect answer.`, 'warn')
      setStatus('Not quite. No reward.')
      if (q.steal) setStealMode(true)
    }
    setReveal(true)
  }
  const finishQuestion = () => {
    setQuestionIndex(i => i + 1); setAnswer(''); setReveal(false); setStealMode(false); setActive(a => 1 - a); setStatus('Next question')
  }
  const stealAnswer = (correct: boolean) => {
    if (correct) {
      updatePlayer(1-active, { bank: players[1-active].bank + 5, bucks: players[1-active].bucks + 25, score: players[1-active].score + 5 })
      addEvent(`${players[1-active].name} steals the answer! +5 Bank Time and +25 BB$.`, 'good')
    } else addEvent(`${players[1-active].name} misses the steal.`, 'warn')
    setStealMode(false); finishQuestion()
  }
  const exportCsv = () => {
    const rows = [['Time','Event','Type'], ...events.map(e => [e.at,e.text,e.kind])]
    const csv = rows.map(r => r.map(v => `"${String(v).replaceAll('"','""')}"`).join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' }); const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = 'boycies-big-balls-game-log.csv'; a.click(); URL.revokeObjectURL(url)
  }
  const nav = [
    ['control','Game Control',Gamepad2], ['player1','Player One',Users], ['player2','Player Two',Users],
    ['showdown','Final Showdown',Trophy], ['events','Event Log',History]
  ] as const
  const changeRound = (r: number) => { setRound(r); setStatus(rounds[r]); addEvent(`Game Master moved to ${rounds[r]}.`) }
  const declareWinner = (name: string) => { setWinner(name); setStatus(`${name} wins!`); addEvent(`${name} declared the winner!`, 'good') }

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-ball">8</div><div><div className="brand-title">{gameTitle}</div><div className="brand-sub">THE PUB GAME SHOW • PROTOTYPE 0.1</div></div></div>
      <div className="top-actions"><span className="live-pill"><i /> LOCAL SESSION</span><button className="icon-btn" title="Settings" onClick={() => setShowSettings(true)}><Settings size={18}/></button></div>
    </header>
    <div className="layout">
      <aside className="sidebar">
        <div className="side-label">GAME MASTER DESK</div>
        {nav.map(([id,label,Icon]) => <button key={id} className={`nav-item ${tab===id?'selected':''}`} onClick={() => setTab(id)}><Icon size={18}/><span>{label}</span></button>)}
        <div className="side-bottom"><div className="connection"><Wifi size={15}/> Local session active</div><div className="version">BUILD 0.1.0 · TEST MODE</div></div>
      </aside>
      <main className="main">
        <div className="page-heading"><div><div className="eyebrow">WELCOME TO THE TABLE</div><h1>{tab==='control'?'Game Control':tab==='player1'?'Player One View':tab==='player2'?'Player Two View':tab==='showdown'?'The Big Balls Showdown':'Game Event Log'}</h1><p>{tab==='control'?'You’re the Game Master. Keep the balls rolling.':tab==='events'?'Every important moment, recorded as it happens.':'A working local preview of the player experience.'}</p></div><div className="round-tag"><span>ROUND {round+1} / 3</span><b>{rounds[round]}</b></div></div>
        <section className="score-grid">
          {players.map((p,i)=><div className={`score-card ${active===i?'active-player':''}`} key={i}><div className="score-top"><span className="player-label"><span className={`player-dot dot-${i}`}></span>{p.name}</span><span className="turn-label">{active===i?'ACTIVE TURN':'STANDING BY'}</span></div><div className="score-number">{p.score}<small>PTS</small></div><div className="resource-row"><div><Clock3 size={15}/><span>Bank Time</span><b>{fmt(p.bank)}</b></div><div><Wallet size={15}/><span>Boycie Bucks</span><b>{p.bucks} BB$</b></div></div></div>)}
        </section>

        {tab==='control' && <div className="content-grid">
          <section className="panel table-panel">
            <div className="panel-heading"><div><span className="eyebrow">THE MAIN EVENT</span><h2>Pool Table Control</h2></div><span className="table-status"><i/> {paused?'PAUSED':'READY'}</span></div>
            <div className="pool-scene"><div className="pool-table"><div className="pocket p1"/><div className="pocket p2"/><div className="pocket p3"/><div className="pocket p4"/><div className="pocket p5"/><div className="pocket p6"/><div className="table-line"/><div className="cue-ball"/><div className="balls"><i/><i/><i/><i/><i/><i/><i/><i/></div><div className="black-ball">8</div></div><div className="table-caption"><Camera size={14}/> TABLE CAMERA PREVIEW <span>Illustrative only</span></div></div>
            <div className="turn-strip"><div><span className="eyebrow">CURRENT PLAYER</span><strong>{current.name}</strong></div><div className="switch-player"><button onClick={()=>setActive(0)} className={active===0?'on':''}>P1</button><button onClick={()=>setActive(1)} className={active===1?'on':''}>P2</button></div></div>
            <div className="shot-actions"><button className="shot pot" onClick={()=>recordShot('POT')} disabled={paused}>POT <span>+10s / +50 BB$</span></button><button className="shot miss" onClick={()=>recordShot('MISS')} disabled={paused}>MISS <span>no reward</span></button><button className="shot foul" onClick={()=>recordShot('FOUL')} disabled={paused}>FOUL <span>provisional -5s</span></button></div>
            <div className="shot-feedback"><Target size={16}/><span>{shot}</span></div>
            <div className="control-footer"><button className="secondary-btn" onClick={()=>{setPaused(!paused);setStatus(paused?'Game resumed':'Game paused');addEvent(paused?'Game resumed.':'Game paused.')}}>{paused?<Play size={16}/>:<Pause size={16}/>} {paused?'Resume game':'Pause game'}</button><button className="secondary-btn" onClick={()=>setActive(1-active)}><RotateCcw size={16}/> Change turn</button></div>
          </section>
          <section className="right-stack">
            <div className="panel round-panel"><div className="panel-heading"><div><span className="eyebrow">GAME PROGRESSION</span><h2>Choose a round</h2></div><Activity size={19}/></div><div className="round-list">{rounds.map((r,i)=><button key={r} className={`round-option ${round===i?'current':''}`} onClick={()=>changeRound(i)}><span className="round-num">0{i+1}</span><span>{r}</span>{round===i&&<span className="round-now">CURRENT</span>}</button>)}</div><div className="note">Balances carry over between rounds. Values are provisional for testing.</div></div>
            <div className="panel question-panel"><div className="panel-heading"><div><span className="eyebrow">QUESTION DECK</span><h2>Quick-fire question</h2></div><CircleHelp size={20}/></div><div className="question-type">{q.type.toUpperCase()} {q.steal&&<span>STEAL ELIGIBLE</span>}</div><p className="question-text">{q.text}</p>{q.options&&<div className="options">{q.options.map(o=><button key={o} className={answer===o?'chosen':''} onClick={()=>setAnswer(o)}>{o}</button>)}</div>}{!q.options&&<input className="answer-input" placeholder="Enter player's answer…" value={answer} onChange={e=>setAnswer(e.target.value)}/>}
              {reveal&&<div className="answer-reveal"><b>Correct answer:</b> {q.answer}</div>}
              {stealMode&&<div className="steal-box"><b>STEAL OPPORTUNITY</b><p>{players[1-active].name}, fancy nicking those points?</p><button onClick={()=>stealAnswer(true)}>Steal – correct</button><button className="ghost-btn" onClick={()=>stealAnswer(false)}>Steal – wrong</button></div>}
              <div className="question-actions">{!reveal?<><button className="primary-btn" disabled={!answer.trim()} onClick={()=>answerQuestion(answer.trim().toLowerCase()===q.answer.toLowerCase() || (q.options?.some(o=>o.toLowerCase()===answer.toLowerCase()) && answer.toLowerCase()===q.answer.toLowerCase()))}>Submit answer</button><button className="secondary-btn" onClick={()=>answerQuestion(false)}>Mark incorrect</button></>:<button className="primary-btn" onClick={finishQuestion}>Next question <Play size={14}/></button>}</div>
            </div>
          </section>
        </div>}

        {(tab==='player1'||tab==='player2') && <section className="panel player-view"><div className="panel-heading"><div><span className="eyebrow">PLAYER PREVIEW</span><h2>{players[tab==='player1'?0:1].name}</h2></div><span className="live-pill"><i/> PREVIEW</span></div><div className="player-hero"><div className="player-avatar">{tab==='player1'?'01':'02'}</div><div><span className="eyebrow">YOUR GAME STATUS</span><h2>{rounds[round]}</h2><p>{status}</p></div></div><div className="player-stats"><div><Clock3/><span>BANK TIME</span><b>{fmt(players[tab==='player1'?0:1].bank)}</b></div><div><Wallet/><span>BOYCIE BUCKS</span><b>{players[tab==='player1'?0:1].bucks} BB$</b></div><div><Award/><span>POINTS</span><b>{players[tab==='player1'?0:1].score}</b></div></div><div className="player-message"><MonitorPlay/><div><b>Broadcast window</b><p>Live pool-table video will appear here when remote broadcasting is added.</p></div></div><div className="player-message"><CircleHelp/><div><b>Question / challenge card</b><p>Questions are currently operated from the Game Master control screen in this local prototype.</p></div></div></section>}

        {tab==='showdown' && <section className="panel showdown-panel"><div className="panel-heading"><div><span className="eyebrow">ROUND THREE</span><h2>The Big Balls Showdown</h2></div><Trophy size={22}/></div><p className="muted">Four object balls each, then the black. First legal black pot after clearing your four wins. This is a visual tracker for the agreed format.</p><div className="showdown-table"><div className="showdown-side"><h3>{players[0].name}</h3><div className="ball-row">{[0,1,2,3].map(i=><button key={i} className="object-ball red-ball" onClick={()=>updatePlayer(0,{balls:Math.max(0,players[0].balls-1)})}>{i+1}</button>)}</div><small>{players[0].balls} balls remaining</small></div><div className="showdown-black"><button className={`object-ball black-eight ${finalBlack?'potted':''}`} onClick={()=>setFinalBlack(!finalBlack)}>8</button><span>THE BLACK</span></div><div className="showdown-side"><h3>{players[1].name}</h3><div className="ball-row">{[0,1,2,3].map(i=><button key={i} className="object-ball yellow-ball" onClick={()=>updatePlayer(1,{balls:Math.max(0,players[1].balls-1)})}>{i+9}</button>)}</div><small>{players[1].balls} balls remaining</small></div></div><div className="winner-actions"><button className="primary-btn" onClick={()=>declareWinner(players[0].name)} disabled={players[0].balls>0}>Declare {players[0].name} winner</button><button className="primary-btn" onClick={()=>declareWinner(players[1].name)} disabled={players[1].balls>0}>Declare {players[1].name} winner</button></div>{winner&&<div className="winner-banner"><Trophy/> {winner} takes the crown!</div>}<div className="note">Prototype note: ball counters are manually operated. Final foul and premature-black penalties remain open design decisions.</div></section>}

        {tab==='events' && <section className="panel events-panel"><div className="panel-heading"><div><span className="eyebrow">SESSION RECORD</span><h2>Event Log</h2></div><button className="secondary-btn" onClick={exportCsv}><Save size={16}/> Export CSV</button></div><div className="event-list">{events.map((e,i)=><div className="event-row" key={i}><span className="event-time">{e.at}</span><span className={`event-dot ${e.kind}`}></span><span>{e.text}</span></div>)}</div><div className="note">This log is held in the current browser session. CSV export creates a local file on your device.</div></section>}
        <footer className="footer"><span>BOYCIE'S BIG BALLS · BUILD 0.1.0</span><span>FOR FUN. PLAY FAIR. BLAME THE CUE.</span></footer>
      </main>
    </div>
    {showSettings&&<div className="modal-backdrop" onClick={()=>setShowSettings(false)}><div className="modal" onClick={e=>e.stopPropagation()}><div className="panel-heading"><div><span className="eyebrow">GAME SETUP</span><h2>Session settings</h2></div><button className="icon-btn" onClick={()=>setShowSettings(false)}><X/></button></div><label>Game title<input value={gameTitle} onChange={e=>setGameTitle(e.target.value)}/></label><label>Player One name<input value={players[0].name} onChange={e=>updatePlayer(0,{name:e.target.value})}/></label><label>Player Two name<input value={players[1].name} onChange={e=>updatePlayer(1,{name:e.target.value})}/></label><label>Relationship mode<select value={relationship} onChange={e=>setRelationship(e.target.value)}><option>Couples</option><option>Family</option><option>Friends</option><option>Strangers</option></select></label><div className="modal-actions"><button className="secondary-btn" onClick={reset}><RotateCcw size={15}/> Reset game</button><button className="primary-btn" onClick={()=>{addEvent(`Session settings updated. Mode: ${relationship}.`);setShowSettings(false)}}>Save settings</button></div></div></div>}
  </div>
}
